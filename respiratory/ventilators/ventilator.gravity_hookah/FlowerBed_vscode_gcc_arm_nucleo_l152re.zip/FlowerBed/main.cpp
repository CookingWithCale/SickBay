/** FlowerBed
    @version 0.9
    @file    /.../Source/FlowerBed/main.cpp
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright (C) 2016 Cale McCollough <calemccollough.github.io>

                      All right reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at
        
            http://www.apache.org/licenses/LICENSE-2.0
        
        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
*/

#define _DebugFlowerBed     1   //< Set to 0 or 1 to enable or disnable debugging.


#include <mbedBug.h>

#include "FlowController.hpp"
using namespace FlowerBed;

FlowController channels[] = {
// Flow sensor ---v    v---- Solenoid
    FlowController (D3, D6, A0),
    FlowController (D4, D7, A1),
    FlowController (D5, D8, A2),
    FlowController (PC_13, D9, A3)
//                    Pot ---^
};

volatile int currentChannel = -1;
volatile bool notEnoughWater = false;

Ticker secondsTicker,
    cycleTicker;

using namespace FlowerBed;
using namespace mbedBug;

#if _DebugFlowerBed
Ticker debugTicker;

void demoTickerISR ()
{
    channels[currentChannel].pulseFlowSensor ();
}
#endif  //< _DebugFlowerBed

void beginCycleTickerISR ()
/*< ISR called at the begining of each watering cycle. */
{
    if (currentChannel >= 0) // Then we are not done watering.
    {
        printf ("Not enough flow on channel %i to match timer!\r\n", 
            currentChannel);
        notEnoughWater = true;
        return;
    }
    
    notEnoughWater = false;
    
    currentChannel = NumChannels - 1;
    printf ("Starting Watering Cycle...\n\r");
    channels[currentChannel].startWatering (currentChannel + 1);
}

void secondTickerISR ()
/*< ISR gets called every second to update the FlowChannel(s). */
{
    if (currentChannel < 0)
    {
        if (notEnoughWater)
        {
            printf ("Resetting cycle timer.\r\n");
            
            /// Reset the cycle timer to cycleTimeSeconds from now.
            
            cycleTicker.detach ();
            beginCycleTickerISR ();
            cycleTicker.attach (&beginCycleTickerISR, cycleTimeSeconds);
            notEnoughWater = false;
        }
        return;
    }
    
    if (channels[currentChannel].checkIfDoneWatering (currentChannel + 1))
    {
        if (--currentChannel < 0)
        {
            if (notEnoughWater)
            {
                printf ("Resetting cycle timer.\r\n\r\n");
                
                /// Reset the cycle timer to cycleTimeSeconds from now.
                
                cycleTicker.detach ();
                beginCycleTickerISR ();
                cycleTicker.attach (&beginCycleTickerISR, cycleTimeSeconds);
                notEnoughWater = false;
            }
            return;
        }
        channels[currentChannel].startWatering (currentChannel + 1);
    }
}

int main ()
{ 
    printf ("\r\n\n\n\n\n\n\n\n\n\n\n\n\r\nStarting FlowerBed...\n\r\n\r");

    secondsTicker.attach (&secondTickerISR, 1.0f);
    
    beginCycleTickerISR (); //< Wont update for a while so call before attaching ISR.
    cycleTicker.attach (&beginCycleTickerISR, cycleTimeSeconds);
    
    #if _DebugFlowerBed
    debugTicker.attach (&demoTickerISR, 1.0f/200.0f);
    #endif //< _DebugFlowerBed
    
    while (1);  //< This is an IRQ driven application.
}
