/** FlowerBed
    @version 0.9
    @file    /.../Source/FlowerBed/FlowController.cpp
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright (C) 2016 Cale McCollough <calemccollough.github.io>

                      All right reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at
        
            http://www.apache.org/licenses/LICENSE-2.0
        
        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
*/

#include "FlowController.hpp"

#include <mbedBug.h>
using namespace mbedBug;

static volatile int secondCount = 0;

namespace FlowerBed {

FlowController::FlowController (PinName sensorPin, PinName solenoidPin, 
    AnalogIn potPin)
:   sensor        (sensorPin),
    valve         (solenoidPin),
    pot           (potPin),
    lastCount     (0),
    count         (0),
    pulseTarget   (calcPulseTarget ())
{
    sensor.rise(this, &FlowController::pulseFlowSensor);
    
}

int32_t convertGallonsToMillileters (float value)
{
    return PulsesPerLiter * (int32_t)(value * 3785.41f);
}

int32_t FlowController::calcTotalFlow_mL ()
{
    return (count * 1000) / PulsesPerLiter;
}

int32_t FlowController::calcTargetFlow_mL ()
{
    return (pulseTarget * 1000) / PulsesPerLiter;
}

int32_t FlowController::calcFlowRate_mL ()
{
    return ((count - lastCount) * 1000) / PulsesPerLiter;
}

void FlowController::startWatering (int index)
{
    lastCount = secondCount = count = 0;
     
    if (pulseTarget == 0)   
    {
        printf ("Cnannel %i is off.\r\n", index);
        return;
    }
    
    openValve ();
}

void FlowController::update (int index)
{
    uint16_t value = calcPulseTarget ();
            
    /// Check for pot noise and 
    if ((value < (pulseTarget - PotNoiseThreshold)) ||
        (value > (pulseTarget + PotNoiseThreshold)))
    {
        pulseTarget = value;
    }
    
    if (pulseTarget == 0) 
    {
        printf ("Turning off channel %i\r\n", index);
        closeValve ();
        return;
    }
    
    printf ("| %2i | %3i | %16u | %15u | %16u |\r\n", index, secondCount, 
        calcFlowRate_mL (), calcTotalFlow_mL (), calcTargetFlow_mL ());
    //printf ("- %8i - %16i - %15i - %16i -\r\n", value,
    //    count - lastCount, count, pulseTarget);
}

bool FlowController::checkIfDoneWatering (int index)
{
    ++secondCount;
    update (index);
    
    /// Check if hit target flow yet.
    
    if (count >= pulseTarget)
    {
        secondCount = 0;
        closeValve ();
        return true;
    }
    lastCount = count;
    return false;
}

void FlowController::pulseFlowSensor ()
{
    ++count;
}

void FlowController::openValve ()
{
    printf ("Opening valve.");
    valve = 1;
    
    printLine ();
    printf ("| Ch | sec | Flow Rate (mL/s) | Total Flow (ml) | Target Flow "
        "(ml) |\r\n");
}

void FlowController::closeValve ()
{
    printf ("Closing valve.");
    valve = 0;
    printLine ();
}

uint16_t FlowController::calcPulseTarget ()
{
    int32_t value = pot.read_u16 ();
    
    /// Update pot and target flow (note: using integer math to multiply by 
    /// number between 0.0 - 1.0.).
    ///
    /// |---- +Va
    /// |---- Max pot reading = Vmax
    /// |---- Pot ADC reading = Vpot
    /// |---- Min pot reading = Vmin
    /// |____ Ground
    ///
    /// 0.0 <= (Vpot - Vmin) / (Vmax - Vmin) <= 1.0
    ///
    
    value -= MinPotReading;
    
    if (value < 0) value = 0;
    
    value = (value * MaxPulsesPerCycle) / 
        PotADCRange;
    
    return (uint16_t)value;
}

}   //< namespace Flowerbed
