/** mbedBug - A library of test and debug utilities for mbed.
    @file    /.../Source/mbedBug/RGBStatusLED.h
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright (C) 2016 Cale McCollough <calemccollough.github.io>

                      All right reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License"); you may 
        not use this file except in compliance with the License. You may obtain 
        a copy of the License at
        
            http://www.apache.org/licenses/LICENSE-2.0
        
        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
        implied. See the License for the specific language governing 
        permissions and limitations under the License.
*/

#ifndef _mbedBug_RGBStatusLED_header
#define _mbedBug_RGBStatusLED_header

#include "mbed.h"

#include <stdint.h>

#define _CreateRGBStatusLED \
static RGBStatusLED<0,1> Status (RED_LED, GREEN_LED, BLUE_LED);\

#define Assert(statement, message)\
{\
    if (!(statement))\
    {\
        printf("Assert: %s\r\n%s, line %d\r\n", #message, __FILE__, __LINE__)\
        Status.HandleAssert ()\
        while (true)\
    }\
}

namespace Primary {

typedef enum 
{
    Black   = 0,
    Red     = 1,
    Yellow  = 2,
    Green   = 3,
    Cyan    = 4,
    Blue    = 5,
    Magenta = 6,
    White   = 7
} Color;
}   //< namespace Primary {

namespace mbedBug {
    
template <int On, int Off>
class RGBStatusLED
/** The onboard mbed RGB LED.
    Some boards have PWM on the RGB LED, some don't. This class uses DigitalOut(s). There are 8 potential combinations 
    of color without PWM (@see Wiki:"Color Space"), Black, Red, Yellow, Green, Cyan, Blue, Magenta, and White.
    
    @code
    RGBStatusLED<0, 1> stausLED (RED_LED, GREEN_LED, BLUE_LED);    //< Use <0, 1> if you're LED is active low.
    RGBStatusLED<1, 0> stausLED (p0, p1, p2);                      //< Use <0, 1> if you're LED is active high.
    
    statusLED.SetColorA (Color::);
    
    @endcode
*/
{
  public:
    
    enum
    {
        DefaultBrightness = 128
    };
    
    RGBStatusLED (PinName redLED, PinName greenLED, PinName blueLED, float blinkDelay = 0.2f)
    /** Simple constructor. */
    :   frequency (aFrequency),
        red       (redLED),
        green     (greenLED),
        blue      (blueLED),
        blinker   (),
        color     (Color::Black),
        colorA    (Color::Black),
        colorB    (Color::Black)
    {
        red = green = blue = 1;
    }
    
    void update ()
    /*< Updates the RGB status LED "frame": color. */
    {
        switch (color)
        {
            case Color::Black  : red = 1; green = 1; blue = 1; return;
            case Color::Red    : red = 0; green = 1; blue = 1; return;
            case Color::Yellow : red = 0; green = 0; blue = 1; return;
            case Color::Green  : red = 1; green = 0; blue = 1; return;
            case Color::Cyan   : red = 1; green = 0; blue = 0; return;
            case Color::Blue   : red = 1; green = 1; blue = 0; return;
            case Color::Magenta: red = 0; green = 1; blue = 0; return;
            case Color::White  : red = 0; green = 0; blue = 0; return;
        }
    }
    
    void setColorA (Primary::Color value)
    /*< Sets colorA. */
    {
        colorA = value; 
    }
    
    void setColorB (Primary::Color value)
    /*< Sets colorB. */
    {
        colorB = value; 
    }
    
    void turnOff ()
    /*< Turns off the blinker. */
    {
        red = green = blue = 1;
    }
    
    void turnOn ()
    /*< Turns on the blinker. */
    { 
        color = colorA; 
        Update ();
    }
    
    void setColors (Primary::Color ColorA, Primary::Color ColorB = Primary::Black)
    /*< Sets the color of the blinker. */
    {
        colorA = ColorA;
        colorB = ColorB;
    }
    
    void flashRedBlue ()
    /*< Starts flashing red and blue lights. */
    {
        colorA = Primary::Red;
        colorB = Primary::Blue;
        StartBlinking ();
    }
    
    void startBlinking ()
    /*< Starts blinking. */
    {
        blinker.attach (this, &RGBStatusLED::Blink, frequency);
        color = colorA;
        Update ();
    }
    
    void stopBlinking  ()
    /*< Stops blinking and turns off the LED. */
    {
        TurnOff ();
        blinker.detach ();
        color = Primary::Black;
        Update ();
    }
    
    void stopBlinkingA ()
    /*< Starts blinking and turns on Color A. */
    {
        color = colorA;
        blinker.detach ();
    }
    
    void stopBlinkingB ()
    /*< Starts blinking and turns on Color B. */
    {
        color = colorB;
        blinker.detach ();
    }
    
    
    void setFrequency (float value)
    /*< Sets the blink frequeny. */
    {
        frequency = value;
        blinker.attach (this, &RGBStatusLED::Blink, value);
    }
    
    void handleAssert ()
    /*< Handler for the Assert macro. */
    {
        FlashRedBlue ()
    }

  private:
    
    float frequency;            //< The frequency of the blinking.
    
    DigitalOut red,             //< Red LED on the mbed board.
         green,                 //< Green LED on the mbed board.
         blue;                  //< Blue LED on the mbed board.
    
    Ticker blinker;             //< Ticker for blinking the LEDs.
    
    uint8_t color,              //< The current color.
        colorA,                 //< Blink color A.
        colorB;                 //< Blink color B.
    
    void blink ()
    /*< Blinks the status RGB LED on the mbed board between colorA and colorB. */
    { 
        color = (color == colorA) ? colorB : colorA;   
        update ();
    }
};
}

// _D_e_m_o_____________________________________________________________________

#if 0   //< Set to non-zero to run this demo.

using namespace mbedBug;

RGBStatusLED Status (LED_RED, LED_GREEN, LED_BLUE);
InterruptIn Switch3 (SW3);

/** Interrupt handler for SW2. */
void SW3Handler ()
{
    static int counter = 16;
    
    if (++counter > 15)
    {
        Status.FlashRedBlue (); counter = 0;
    }
    else if (counter & 1)
    { 
        Status.StopBlinking  ();
    }
    else    
    {  
        Status.SetColorA ((Primary::Color)(counter >> 1));
        Status.SetColorB (Primary::Black);
        Status.StartBlinking ();
    }
}

int main()
{
    printf ("\r\nTesting mbed Utils.\r\n");
    PrintLine ('-');
    
    Switch3.rise (&SW3Handler);
    //Status.StartBlinking ();
    
    while (true);
}
#endif  //< #if _Demo

#endif  //< _mbedBug_RGBStatusLED_header
