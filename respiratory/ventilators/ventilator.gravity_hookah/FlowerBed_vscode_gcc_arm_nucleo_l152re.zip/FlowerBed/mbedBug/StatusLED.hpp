/** mbedBug - A library of test and debug utilities for mbed.
    @file    /.../Source/mbedBug/StatusLED.h
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright (C) 2016 Cale McCollough <calemccollough.github.io>

                      All right reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License"); you may 
        not use this file except in compliance with the License. You may obtain 
        a copy of the License at
        
            http://www.apache.org/licenses/LICENSE-2.0
        
        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or 
        implied. See the License for the specific language governing 
        permissions and limitations under the License.
*/

#ifndef _mbedBug_StatusLED_header
#define _mbedBug_StatusLED_header

#define _Debug 0    //< Use this flag to turn this library into a debug example program. @see mbedBug.cpp:int main ()

#include <mbed.h>

#include <stdint.h>

#define _CreateStatusLED \
static StatusLED<0,1> status (GREEN_LED);\

#define Assert(statement, message)\
{\
    if (!(statement))\
    {\
        printf("Assert: %s\r\n%s, line %d\r\n", #message, __FILE__, __LINE__)\
        status.HandleAssert ()\
        while (true)\
    }\
} 

namespace mbedBug {

template <int On, int Off>
class StatusLED
/** Outputs the firmware status using the LED on the mbed board.
    This class works by using strings with ASCII Mores Code. Each char in a 
    represents a pulse split into 4 lengths.
    
    | Frame | ASCII | Index | Duty Cycle |
    |:-----:|:-----:|:-----:|:----------:|
    | Off   | ' '   | <= 44 |     0%     |
    | Long  | '-'   | 45    |    1/3     |
    | Short | '.'   | 46    |    1/3     |
    | On    | '_'   | >= 47 |   100%     |
    
    Off could be any value less than 44, and On could be any value greater than 
    47, but ASCII space (' ') and period ('.') are used by convention because 
    they look like the pulse widths.
    
    ## Terminology
    * Frame    - Each character in a char sequence represeents 3 timer interrupts.
    * Pattern  - A null-terminated string of frames.
    * Sequence - A null-terminated string of const char*.
    
    @code
    StatusLED<0, 1> stausLED ();        //< Use <0, 1> if you're LED is active low.
    StatusLED<1, 0> stausLED (LED_2);   //< Use <0, 1> if you're LED is active high.
        
    const char* examplePattern[] = { 
        "...   ",       //< Blinks fast three times in a row.
        "...---...   ", //< SOS in Mores Code.
        "____    ",     //< Slowly blinks on and off.
        0               //< Must have null-termination pointer.
    };
    
    statusLED.SetPattern (exapmlePattern, 1.5f);
    
    @endcode
*/
{
  public:
    
    static const float DefaultFrequency = 0.5f, //< Default frequency in hertz.
        MinFrequency = 0.01f,                   //< Min frequency in hertz.
        MaxFrequency = 2.0f;                    //< Max frequency in hertz.
    
    typedef enum {
        Off     = 0,
        Short   = 63,
        Long    = 127,
        On      = 255
    } Pulse;
    
    StatusLED (PinName LEDPin = LED_1, float Frequency = DefaultFrequency)
    /** Simple constructor. */
    :   count     (0),
        period    (0),
        sequence  (0),
        pattern   (0),
        cursor    (0),
        frequency (Frequency),
        pin       (LEDPin, Off)
    {
        /// Nothing to do here.
    }
    
    void setSequence (char** newSequence)
    /** Sets the light blinking sequence. */
    {
        if (newSequence == nullptr)
        {
            sequence = 0;
            stopBlinking ();
            return;
        }
        
        const char* tempString = sequence[0];
        
        if (tempString == 0 || tempString[0] == 0) 
        {
           #if _Debug
            printf ("\r\n\nError: First sequence and first char can't be null.\r\n\n");
           #endif
            return;
        }
        sequence = newSequence;
        pattern = newSequence[0];
        cursor = pattern;
        currentByte = *cursor;
        update ();
    }
    
    void turnOff ()
    /** Turns off the blinker. */
    {
        pin = Off; 
    }
    
    void turnOn ()
    /** Turns on the blinker. */
    { 
        color = colorA;
        update (); 
    }
    
    void flashSOS ()
    /** Starts flashing the SOS sequence. */
    {
        sequence = sosPattern ();
        const char* _cursor = sequence[0];
        cursor = *_cursor;
        period = *_cursor;
    }
    
    void startBlinking ()
    /** Starts blinking. */
    {
        const char* _pattern = sequence[0];
        pattern = _pattern;
        cursor = _pattern;
        period = *_pattern;

        blinker.attach (this, &StatusLED::blink, frequency / 4);
        update ();
    }
    
    void stopBlinking  ()
    /** Stops blinking and turns off the LED. */
    {
        turnOff ();
        blinker.detach ();
        pin = Off;
        Update ();
    }
    
    void setFrequency (float Value)
    /** Sets the blink frequeny. */
    {
        frequency = Value;
        blinker.attach (this, &StatusLED::Blink, Value);
    }
    
    void handleAssert ()
    /** Handler for the Assert macro. */
    {
        setPattern (sosPattern ());
    }
    
    const char** blink3TimesPattern ()
    /** Pattern blinks three times in a row. */
    {
        static const char** sequence = { "...   ", 0 };
        return &sequence;
    }

    const char** slowBlinkPattern ()
    /** Standard blink sequence. */
    {
        static const char** sequence = { "__  ", 0 };
        return &sequence;
    }
    
    const char** fastBlinkPattern ()
    /** Standard blink sequence. */
    {
        static const char** sequence = { "_ ", 0 };
        return &sequence;
    }
    
    const char** sosPattern ()
    /** Standard SOS sequence. */
    {
        static const char** sequence = { "...---...      ", 0 };
        return &sequence;
    }

  private:
  
    char count,             //< Counter counts from from 1-3.
        period;             //< The current period char.
    
    float frequency;        //< The period length

    const char** sequence;  //< Null-terminated string of pointers.
    
    const char* pattern,    //< The current string in the sequence.
        * cursor;           //< The current char in the current string.
    
    DigitalOut pin;         //< Red LED on the mbed board.
    
    Ticker blinker;         //< Ticker for blinking the LEDs.
    
    inline char getNextPeriod ()
    /** Returns the next char in the sequence. */
    {
        /// We've already checked that the sequence and cursor and not null.
        
        char periodTemp = *(++cursor);
        
        if (periodTemp == 0)
        {
            const char* tempPattern = *(pattern + sizeof (const char*));
            
            if (tempPattern == nullptr)
            {
                const char* _cursor = sequence[0];
                cursor = pattern = _cursor;
                return *_cursor;
            }
            pattern = tempPattern;
            return *tempPattern;    //< We don't particularly care if the period is '\0'.
        }
        
        return periodTemp;
    }
    
    inline void update ()
    /** Updates the status LED. */
    {
        const char* periodTemp = period;
        if (sequence == nullptr || periodTemp == nullptr) return;
        
        if (count == 0)         //< Beginning of cycle period.
        {
            char _period = getNextPeriod ();
            period = _period;
            count = 1;
            if (_period < '-') 
            {
                pin = Off; 
                return; 
            }
            pin = On;
            return;
        }
        else if (count == 1)    //< 1/3 duty cycle.
        {
            count = 2;
            if (period == '.')
            {
                pin = Off; 
                return; 
            }
            return;
        }
        /// 2/3 duty cycle.
        count = 0;
        if (period > '.')       //< Leave the LED on
            return;
        pin = Off;
    }
};
}

// _D_e_m_o_____________________________________________________________________

#if 0   //< Set to non-zero to run this demo.

using namespace mbedBug;

StatusLED status ();
InterruptIn switch3 (SW3);

const char* examplePattern[] = {
    "...   ",           //< Blinks fast three times in a row.
    "...---...      ",  //< SOS in Mores Code.
    "____    ",         //< Slowly blinks on and off.
    0                   //< Pattern must have null-term pointer.
};
/** Interrupt handler for SW2. */
void switchIRQHandler ()
{
    static bool examplePatterMode = true;
    
    if (examplePatterMode)
    {
        status.setPattern (examplePattern);
        status.startBlinking ();
        examplePatterMode = false;
    }
    else    
    {  
        status.setPattern(status.SOSPattern ()));
        examplePatterMode = true;
    }
}

int main()
{
    printf ("\r\n\nTesting mbed Utils.\r\n\n");
    PrintLine ();
    
    switch3.rise (&SwitchIRQHandler);
    //status.StartBlinking ()
    
    while (true);
}

#endif  //< Demo
#endif  //< _mbedBug_StatusLED_header
