/** mbedBug - A library of test and debug utilities for mbed.
    @file    /.../mbedBug/mbedBug.cpp
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright 2016 (C) Cale McCollough <https://calemccollough.github.io>.
        All rights reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License"); you may
        not use this file except in compliance with the License. You may obtain
        a copy of the License at

            http://www.apache.org/licenses/LICENSE-2.0

        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
        implied. See the License for the specific language governing
        permissions and limitations under the License.
*/

#pragma once

#include <mbedBug-Config.h>

namespace mbedBug {

template<unsigned int MaxNumErrors>
class ErrorList
/** An array of error strings.
    @code
    ErrorList<5> errors;

    @endcode
*/
{
  public:

    ErrorList ()
    /** Default simple constructor. */
    :   numErrors (0)
    {
        /// Nothing to do here! :-)
    }

    void Clears () { numErrors = 0; }
    /*< Clears the error list. */

    unsigned int GetNumErrors () { return numErrors; }
    /*< Gets the number of errors. */

    void Report (const char* Error)
    /** Reports an error with the given message. */
    {
        if (numErrors >= MaxNumErrors) return;
        errors[numErrors++] = Error;
        return this;
    }
    ErrorList& operator += (const char* Error)
    /** Reports an error with the given message. */
    {
        Report (Error);
        return this;
    }

    virtual void Print ()
    {
        for (int i = 0; i < numErrors; ++i)
            printf ("\r\n%s", errors[i]);
    }

    const char* GetErrors () { return errors; }
    /*< Returns the list of errors. */

  private:

    unsigned int numErrors;

    const char* errors[MaxNumErrors];
};

}   //< namespace mbedBug {
