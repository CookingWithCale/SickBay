/** FlowerBed
    @version 0.9
    @file    /.../Source/FlowerBed/FlowController.hpp
    @author  Cale McCollough <cale.mccollough@gmail.com>
    @license Copyright (C) 2016 Cale McCollough <calemccollough.github.io>

                      All right reserved (R).

        Licensed under the Apache License, Version 2.0 (the "License");
        you may not use this file except in compliance with the License.
        You may obtain a copy of the License at
        
            http://www.apache.org/licenses/LICENSE-2.0
        
        Unless required by applicable law or agreed to in writing, software
        distributed under the License is distributed on an "AS IS" BASIS,
        WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        See the License for the specific language governing permissions and
        limitations under the License.
*/

#pragma once

#include <mbed.h>
#include <stdint.h>

#include "FlowerBed-Config.hpp"

namespace FlowerBed {

class FlowController
{
  public:
    
    FlowController (PinName sensorPin, PinName solenoidPin, AnalogIn potPin);
    /*< Constructs a smart waterer. */
    
    int32_t calcTotalFlow_mL ();
    /*< Calculates the total flow in millilters. */
    
    int32_t calcTargetFlow_mL ();
    /*< Calculates the target flow in millilters. */
    
    int32_t calcFlowRate_mL ();
    /*< Calculates the flow rate in millilters. */
        
    void startWatering (int index);
    /*< StartWaterings to the begining of the watering cycle. */
    
    void pulseFlowSensor ();
    /*< Increments theflow rate sensor pulse counter. */
    
    void print (int index);
    /*< Prints the state of object to the debug stream. */
    
    void update (int index);
    /*< Polls the pot and updates the target flow. */
    
    bool checkIfDoneWatering (int index);
    /*< Updates the float rate. */
    
    void openValve ();
    /*< Opens the solenoid valve. */
    
    void closeValve ();
    /*< Closes the solenoid valve. */
    
  private:
    
    InterruptIn sensor;         //< The flow sensor pin.
    DigitalOut  valve;          //< The solenoid valve pin.
    AnalogIn pot;               //< The potentiometer pin.

    volatile uint16_t lastCount,//< The previous saved count.
        count;                  //< Flow sensor pulse count.
    
    uint16_t pulseTarget;       //< The terget pulse count.
    
    inline uint16_t calcPulseTarget ();
    /*< Calculates the pulse target value from the pot value. */
};

}   //< namespace Flowerbed